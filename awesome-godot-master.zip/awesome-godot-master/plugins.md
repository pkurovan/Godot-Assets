# Plugins / Modules

[![Godot Awesome List](icons/button.png)](https://github.com/hto/awesome-godot)

## Navigation
- [TileMap Navigation - Isometric and Hex (Github)](https://github.com/kidscancode/godot_tilemap_navigation) - TileMap navigation and avoid the common pitfalls, even when using isometric or hex-shaped tiles!
- [TileMap Navigation - Isometric and Hex (Youtube)](https://www.youtube.com/watch?v=OYn49ghh9k0) - TileMap navigation and avoid the common pitfalls, even when using isometric or hex-shaped tiles!
- [Pathfinding on a TileMap with Navigation2D (Youtube)](https://www.youtube.com/watch?v=0fPOt0Jw52s)
