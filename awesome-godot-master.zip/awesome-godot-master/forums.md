# Forum / Community Important Titles

[![Godot Awesome List](icons/button.png)](https://github.com/hto/awesome-godot)

## Twitter
- [Godot Engine](https://twitter.com/godotengine) - Godot Engine Twitter Page
- [Johnny](https://twitter.com/johnnygossdev) - A developer that prepares content on useful and current topics
- [GDQuest](https://twitter.com/NathanGDQuest) - 400+ free tutorials, GDQuest Youtube Channel's twitter page

## Global 
- [Telegram - GodotNews](https://telegram.me/godotnews) - Inofficial Godot News channel. This channel is using a small python script checking for new news on https://godotengine.org/news every 15 minutes and posting the links here.

## Forums & Groups 
- [Godot Engine](https://godotforums.org/) - Godot Engine Offical Forum Page


