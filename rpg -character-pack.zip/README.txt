--------------------------------------------
v6

Add splitted spritesheets in the full version to match the ARPG package index and format

--------------------------------------------
v5

fix spritesheets format for rpgmaker users

--------------------------------------------
v4

add a free nude character animation

--------------------------------------------
v3

export free and full version

--------------------------------------------
v2

test

-------------------------------------------
v1

first export test

